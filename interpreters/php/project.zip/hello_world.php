<?php
require_once("Android.php");
$droid = new Android();
$droid->makeToast('Hello');
